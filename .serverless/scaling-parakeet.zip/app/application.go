package application

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/service/dynamodb"
	"github.com/aws/aws-sdk-go/service/dynamodb/dynamodbattribute"
	"github.com/google/uuid"
)

type Application struct {
	// config AppConfig
	db *dynamodb.DynamoDB
}

type AppConfig struct{}

type User struct {
	Id   string `json:"id"`
	Name string `json:"name"`
}

func (app *Application) createUser() (*User, error) {
	userId := uuid.New().String()
	fmt.Println("Generated new user id:", userId)

	user := &User{
		Id:   userId,
		Name: "TEST",
	}

	av, err := dynamodbattribute.MarshalMap(user)
	if err != nil {
		fmt.Println("Error marshalling item: ", err.Error())
		return nil, fmt.Errorf("failed marshalling item: %s", err)
	}

	tableName := os.Getenv("DYNAMODB_TABLE")

	input := &dynamodb.PutItemInput{
		Item:      av,
		TableName: aws.String(tableName),
	}
	app.db.PutItem(input)
	if err != nil {
		return nil, fmt.Errorf("Got error calling PutItem: %s", err)
	}

	return user, nil
}

func (app *Application) buildUserResponse(user *User, code int) events.APIGatewayProxyResponse {
	// Marshal item to return
	jsonMarshalled, _ := json.Marshal(user)

	return events.APIGatewayProxyResponse{StatusCode: code, Body: string(jsonMarshalled)}
}

func (app *Application) HandleRequest(request events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
	var user *User
	var err error
	var response events.APIGatewayProxyResponse
	switch request.HTTPMethod {
	case "POST":
		user, err = app.createUser()
		response = app.buildUserResponse(user, 201)
	default:
		response = events.APIGatewayProxyResponse{StatusCode: 400, Body: "Invalid request"}
	}

	if err != nil {
		errMessage := fmt.Sprintf("Request failed: %s", err)
		return events.APIGatewayProxyResponse{StatusCode: 500, Body: errMessage}, nil
	}

	return response, nil
}
