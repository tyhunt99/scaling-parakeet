package application

import "testing"

func TestCreateUser(t *testing.T) {
	t.Fatalf("BAD")
}
